console.log("LinkedIn Feed Filter content script injected. Starting to modify posts...");

(async function main() {
    const processedImages = new Set();
    const imagesAwaitingClassification = new Map();
    const processedTextElements = new Set();
    setupMutationObserver();

    const filterWords = await loadStorageData('filterWords');
    const filterWordsPrefix = await loadStorageData('filterWordsPrefix');

    async function modifyLinkedInContent() {
        await modifyLinkedInPosts();
        await classifyAndModifyImages();
    }

    async function classifyAndModifyImages() {
        const selectedImages = Array.from(document.querySelectorAll('img.update-components-image__image'))
            .filter(img => img.clientWidth >= 100 || img.clientHeight >= 100);

        console.debug("Filtered Images:", selectedImages.length);
        for (let img of selectedImages) {
            if (processedImages.has(img.src) || imagesAwaitingClassification.has(img.src)) {
                continue;
            }
            console.debug(`Processing image: ${img.src}`);
            processedImages.add(img.src);
            console.debug("Processed images:", processedImages);

            const requestBody = createRequestBody(img.src);
            if (!requestBody) {
                console.error("Failed to create request body for image:", img.src);
                continue;
            }
            try {
                console.debug("Sending image for classification", JSON.stringify(requestBody, null, 2));
                imagesAwaitingClassification.set(img.src, fetchImageClassification(requestBody).then(response => {
                    console.debug("Received response:", JSON.stringify(response, null, 2));
                    if (response.choices && response.choices.length > 0) {
                        const classificationText = response.choices[0].message.content;
                        console.debug("Classification result:", classificationText);
                        return applyImageOverlay(img, classificationText);
                    } else {
                        console.warn("Unexpected response structure:", response);
                    }
                }).catch(error => {
                    console.error("Error in classification promise:", error);
                }).finally(() => {
                    imagesAwaitingClassification.delete(img.src);
                }));
                await imagesAwaitingClassification.get(img.src);
            } catch (error) {
                console.error("Error classifying image with the Cloud Function:", error);
            }
        }
    }

    function createRequestBody(imageSrc) {
        if (!imageSrc) {
            console.error("No image source provided to createRequestBody");
            return null;
        }
        console.debug("Creating request body for image:", imageSrc);
        const requestBody = {
            data: {
                model: "gpt-4o-mini",
                messages: [
                    {
                        role: "user",
                        content: [
                            { type: "text", text: "ONLY RESPOND WITH THE CLASSIFICATION 'selfpromotional_image' OR 'other': You are an AI that detects self-promotional LinkedIn images. Classify the following image as either 'selfpromotional_image' (selfies, headshots of one person) or 'other' (no people, multiple people, not self-promotional)." },
                            {
                                type: "image_url",
                                image_url: {
                                    url: imageSrc
                                }
                            }
                        ]
                    }
                ]
            },
            max_tokens: 300
        };
        console.debug("Created request body:", JSON.stringify(requestBody, null, 2));
        return requestBody;
    }

    async function fetchImageClassification(requestBody) {
        console.debug("Fetching image classification with body:", JSON.stringify(requestBody, null, 2));
        return fetch('https://us-central1-linkedin-unhumbled.cloudfunctions.net/linkedin-unhumbled/classify_image', {
            method: 'POST',
            mode: 'cors',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify(requestBody)
        })
            .then(response => {
                console.debug("Received response status:", response.status);
                return response.json();
            })
            .then(data => {
                console.log("Received response for image classification:", JSON.stringify(data, null, 2));
                return data;
            })
            .catch(error => {
                console.error('Error in fetchImageClassification:', error);
                throw error;
            });
    }

    async function applyImageOverlay(img, classification) {
        if (classification.toLowerCase().includes("selfpromotional_image")) {
            console.debug("Applying image overlay for selfie for image: ", img.src);
            const selectedImageUrl = await getSelectedImageUrl();
            let overlay = document.createElement('img');
            overlay.src = selectedImageUrl;
            setOverlayStyle(overlay, img);
            img.parentNode.insertBefore(overlay, img.nextSibling);
            overlay.style.transition = "opacity 2s";
            overlay.style.opacity = 0;
            setTimeout(() => overlay.style.opacity = 0.69, 2000);
            overlay.addEventListener('click', () => overlay.remove());
        }
    }

    async function getSelectedImageUrl() {
        return new Promise(resolve => {
            chrome.storage.sync.get('selectedImage', function (data) {
                const imageUrlMap = {
                    'dog_gif': chrome.runtime.getURL("assets/dog.gif"),
                    'dog_static': chrome.runtime.getURL("assets/dog_static.png")
                };
                resolve(imageUrlMap[data.selectedImage || '']);
            });
        });
    }
    
    function setOverlayStyle(overlay, img) {
        overlay.style = `position: absolute; width: ${img.offsetWidth}px; height: ${img.offsetHeight}px; left: 0; top: 0; object-fit: cover; z-index: 1000;`;
        overlay.style.opacity = 0.69;
        img.parentNode.style.position = "relative";
        img.style.objectFit = "cover";
    }

    async function modifyLinkedInPosts() {
        try {
            console.debug("Starting modifyLinkedInPosts");
            
            let prefix = '';
            const actualPrefix = filterWordsPrefix[0];

            switch (actualPrefix) {
                case 'humbled': prefix = '😌'; break;
                case 'clown': prefix = '🤡'; break;
                case 'poop': prefix = '💩'; break;
                default: console.warn("Unknown prefix:", actualPrefix);
            }
        
            const textViewElements = document.querySelectorAll('span.text-view-model');
            console.debug("Found text view elements:", textViewElements.length);
            
            textViewElements.forEach((textViewElement, index) => {
                try {
                    if (!textViewElement || processedTextElements.has(textViewElement)) {
                        console.debug(`Skipping element ${index}: already processed or null`);
                        return;
                    }

                    const postText = textViewElement.innerText ? textViewElement.innerText.toLowerCase() : '';
                    console.debug(`Processing element ${index}, text:`, postText.substring(0, 50) + '...');

                    if (filterWords.some(word => postText.includes(word)) && !textViewElement.classList.contains('modified')) {
                        textViewElement.innerText = prefix.repeat(12) + "\n" + textViewElement.innerText;
                        textViewElement.style.color = "#ebe7e7";
                        textViewElement.classList.add('modified');
                        textViewElement.querySelectorAll('a').forEach(link => link.style.color = "lightgrey");
                        processedTextElements.add(textViewElement);
                        console.debug(`Modified element ${index}`);
                    }
                } catch (elementError) {
                    console.error(`Error processing element ${index}:`, elementError);
                }
            });
        } catch (error) {
            console.error("Error in modifyLinkedInPosts:", error);
        }
    }

    async function loadStorageData(key) {
        return new Promise((resolve, reject) => {
            chrome.storage.sync.get(key, function(data) {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    let result = data[key];
                    if (typeof result === 'string') {
                        result = result.split(',').map(item => item.trim());
                    }
                    resolve(result);
                }
            });
        });
    }    

    function setupMutationObserver() {
        let observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0 && !mutation.target.classList.contains('modified')) {
                    modifyLinkedInContent();
                }
            });
        });
        const targetNode = document.querySelector('#main-feed') || document.body;
        observer.observe(targetNode, { childList: true, subtree: true });
    }
})();